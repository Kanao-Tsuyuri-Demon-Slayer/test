function updateQuantity(eggs,bread){
    let qtyInput=document.getElementById(eggs);
    console.log(qtyInput);
   
}
